walkthrough is coming soon! will post it on ludum dare, and add to this archive when it's available.

Please send any thoughts or bug reports to jordan@necessarygames.com, or post on my Ludum Dare entry. 


Any feedback is much appreciated!



Tahnk you,

Jordan Magnuson
necessarygames.com